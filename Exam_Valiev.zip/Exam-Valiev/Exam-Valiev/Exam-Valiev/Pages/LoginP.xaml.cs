﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Exam_Valiev.Pages;
namespace Exam_Valiev.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginP.xaml
    /// </summary>
    public partial class LoginP : Page
    {
        public LoginP()
        {
            InitializeComponent();
        }

        private void BSignIn_Click(object sender, RoutedEventArgs e)
        {
            string login = TBLogin.Text;
            string password = TBPassword.Text;
            string secretword = TBSecret.Text;


            var loggedSotrudnik = App.DB.Sotrudniki.FirstOrDefault(x => x.Login == login && x.Password == password && x.Secret == secretword);

            if (loggedSotrudnik == null)
            {
                MessageBox.Show("поля пусты или неверно заполнены");
                return;
            }

            App.LoggedSotrudnik = loggedSotrudnik;
            NavigationService.Navigate(new CleanMMenuP());
        }
    }
    }

